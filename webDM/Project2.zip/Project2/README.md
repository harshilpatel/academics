PROJECT: Project 2
Course: WDM
Duration: Spring 2020

GOAL: To demonstrate html pages for the burger restaurant website

Members:
- 
- 